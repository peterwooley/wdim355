$(function() {
  // ColorChanger Model

  // ColorChanger Collection

  // ColorChanger View

  // AppView
});
