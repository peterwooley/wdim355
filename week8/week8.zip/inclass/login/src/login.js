/* Implement Login Object Constructor */
