/* Implement Train Object Constructor */

